(ns oho.routes.home
  (:use ring.util.response)
  (:require
    [oho.models.db :as db]
    [oho.views.layout :refer :all]))


(defn index []
  (base))

(defn trade []
  (db/get-my-trade-with-products 4))